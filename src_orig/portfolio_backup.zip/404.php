<?php include 'header.html'; ?>
    <!-- masthead -->
    <div class="jumbotron">
      <h2 class="jumbotron--title">Ooops</h2>
      <p class="jumbotron--sub-title">That page doesn't exist or has been moved</p>
    </div><!-- /masthead -->
<?php include 'footer.html'; ?>
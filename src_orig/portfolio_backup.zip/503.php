<?php include 'header.html'; ?>
    <!-- masthead -->
    <div class="jumbotron">
      <h2 class="jumbotron--title">Zzzzz</h2>
      <p class="jumbotron--sub-title">We've gone for a nap, come back soon!</p>
    </div><!-- /masthead -->
<?php include 'footer.html'; ?>
// homepage slider //

$('.homepageslider').bxSlider({
  pagerCustom: '#bx-pager'
});